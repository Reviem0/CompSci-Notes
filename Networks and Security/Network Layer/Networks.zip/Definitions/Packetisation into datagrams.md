This involves taking a chunk of data that needs to be sent and adding an [[IP Header]] in front of it, effectively turning it into a datagram
